# ALU-Remapper-and-MouseMode-Arcadia6
This file was created to be used with the AtGames Legends Ultimate in USB OTG mode with CoinOPS Arcadia 6 / RetroFE. Currently supported emulator is MaMe.

MaMe keys: Rewind + P1 = Exit Game, Rewind + Menu = MaMe Configuration menu.

Setting [D] Opens Devices and Printers to so you can check if the ALU is showing up correctly.

[C] Add Mouse Mode to startup and run joystick mouse mode which allows you to use the ALU P1 and P2 controls to act like a mouse. Please be aware that this ALU OTG MM may throw a false positive on your virus scanner due to using MPRESS on the executable to make the executable smaller. This is the latest version (this will also check if running as admin, if not it will run as admin to be able to click on some other windows such as onscreenkeyboard).

A = Left Click 
B = Right Click
C = Middle Click (scrolling)

P1 A + Menu = Enable / Disable P1 MM
P2 A + Menu = Enable / Disable P2 MM

Rewind + P1 = Close App
Z + Menu = Open / Close x360ce 4.10 

*If you are using [C] This will run the takeown command allowing your account full access to the coinops folder and sub-folders. This make take some time if you have lot of add-on packs or the larger CoinOPS next file.
Special thanks to AtGames for an Awesome Arcade and the creators and members of RetroFE and CoinOPS. - VariableBits

---------------------------------
- Installation
---------------------------------
Copy to the root folder of CoinOPS Arcadia 6 and run the Restore ALU USB OTG Arcade 6.exe file.
